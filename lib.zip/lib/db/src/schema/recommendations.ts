import { pgTable, serial, text, integer, numeric, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const recommendationSessionsTable = pgTable("recommendation_sessions", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(),
  budget: numeric("budget", { precision: 12, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("USD"),
  useCase: text("use_case").notNull(),
  preferences: jsonb("preferences").$type<string[]>().notNull().default([]),
  brandPreferences: jsonb("brand_preferences").$type<string[]>().notNull().default([]),
  location: text("location"),
  additionalNotes: text("additional_notes"),
  products: jsonb("products").notNull().default([]),
  summary: text("summary").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertRecommendationSessionSchema = createInsertSchema(recommendationSessionsTable).omit({ id: true, createdAt: true });
export type InsertRecommendationSession = z.infer<typeof insertRecommendationSessionSchema>;
export type RecommendationSession = typeof recommendationSessionsTable.$inferSelect;
