import { Link } from "wouter";
import { format } from "date-fns";
import { useListRecommendations, useDeleteRecommendation, getListRecommendationsQueryKey } from "@workspace/api-client-react";
import { Trash2, ExternalLink, ArrowRight, PackageOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useQueryClient } from "@tanstack/react-query";

export default function History() {
  const queryClient = useQueryClient();
  const { data: sessions, isLoading } = useListRecommendations();
  const deleteMutation = useDeleteRecommendation();

  const handleDelete = (id: number) => {
    deleteMutation.mutate({ id }, {
      onSuccess: () => {
        // Invalidate list to refresh
        queryClient.invalidateQueries({ queryKey: getListRecommendationsQueryKey() });
      }
    });
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-5xl">
      <div className="flex items-end justify-between mb-10">
        <div>
          <h1 className="text-4xl font-black tracking-tight mb-2">History</h1>
          <p className="text-muted-foreground text-lg">Your past recommendation sessions.</p>
        </div>
        <Link href="/recommend">
          <Button className="rounded-full shadow-md gap-2 font-semibold">
            New Pick <ArrowRight className="w-4 h-4" />
          </Button>
        </Link>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <Skeleton key={i} className="h-32 w-full rounded-2xl" />
          ))}
        </div>
      ) : sessions?.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center border-2 border-dashed border-border/60 rounded-3xl bg-muted/20">
          <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center text-primary mb-6">
            <PackageOpen className="w-12 h-12" />
          </div>
          <h3 className="text-2xl font-bold mb-3">No history yet</h3>
          <p className="text-muted-foreground max-w-md mb-8">
            You haven't asked for any recommendations yet. Try our advisor to find your perfect tech.
          </p>
          <Link href="/recommend">
            <Button size="lg" className="rounded-full px-8 h-14 text-lg">
              Start Your First Pick
            </Button>
          </Link>
        </div>
      ) : (
        <div className="grid gap-4">
          {sessions?.map((session) => {
            const topPick = session.products[0];
            return (
              <div 
                key={session.id} 
                className="group flex flex-col sm:flex-row items-center gap-6 bg-card border border-border rounded-2xl p-4 md:p-6 hover:border-primary/40 hover:shadow-lg transition-all duration-300"
              >
                {/* Image thumb */}
                {topPick && (
                  <div className="w-full sm:w-28 h-28 shrink-0 bg-white rounded-xl p-2 border border-border/50 flex items-center justify-center">
                    <img src={topPick.imageUrl} alt={topPick.name} className="max-w-full max-h-full object-contain mix-blend-darken" />
                  </div>
                )}
                
                <div className="flex-1 flex flex-col justify-center min-w-0">
                  <div className="flex items-center gap-3 mb-2 flex-wrap">
                    <Badge variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                      {session.category}
                    </Badge>
                    <span className="text-sm font-medium text-muted-foreground">
                      ${session.budget} Budget
                    </span>
                    <span className="text-xs text-muted-foreground ml-auto hidden sm:inline-block">
                      {format(new Date(session.createdAt), "MMM d, yyyy")}
                    </span>
                  </div>
                  
                  <h3 className="font-bold text-xl truncate mb-1">
                    {topPick ? `Top pick: ${topPick.name}` : 'No products found'}
                  </h3>
                  
                  <p className="text-sm text-muted-foreground truncate">
                    For: {session.useCase}
                  </p>
                </div>

                <div className="flex sm:flex-col items-center sm:items-end gap-3 w-full sm:w-auto mt-4 sm:mt-0 pt-4 sm:pt-0 border-t border-border/50 sm:border-t-0 shrink-0">
                  <Link href={`/results/${session.id}`} className="flex-1 sm:flex-none">
                    <Button variant="secondary" className="w-full sm:w-auto rounded-xl group-hover:bg-primary group-hover:text-primary-foreground transition-colors gap-2">
                      View Results <ExternalLink className="w-4 h-4" />
                    </Button>
                  </Link>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-xl"
                    onClick={() => handleDelete(session.id)}
                    disabled={deleteMutation.isPending}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
