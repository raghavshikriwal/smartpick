import { useLocation, Link } from "wouter";
import { useGetRecommendation, getGetRecommendationQueryKey } from "@workspace/api-client-react";
import { ArrowLeft, CheckCircle2, XCircle, ShoppingCart, MapPin, AlertCircle, Sparkles, ExternalLink, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
// Platform icon using a styled letter badge
const getStoreIcon = (platform: string) => {
  return <ShoppingCart className="w-4 h-4" />;
};

const getStoreColor = (platform: string) => {
  const p = platform.toLowerCase();
  if (p.includes('amazon')) return "bg-[#FF9900] text-black hover:bg-[#FF9900]/90";
  if (p.includes('best')) return "bg-[#0046BE] text-white hover:bg-[#0046BE]/90";
  if (p.includes('flipkart')) return "bg-[#2874F0] text-white hover:bg-[#2874F0]/90";
  return "bg-primary text-primary-foreground hover:bg-primary/90";
};

export default function Results({ params }: { params: { id: string } }) {
  const id = parseInt(params.id);
  const [, setLocation] = useLocation();

  const { data: session, isLoading, isError } = useGetRecommendation(id, {
    query: {
      enabled: !isNaN(id) && id > 0,
      queryKey: getGetRecommendationQueryKey(id)
    }
  });

  if (isNaN(id)) {
    return <div className="p-8 text-center text-destructive">Invalid Session ID</div>;
  }

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 max-w-6xl">
        <Skeleton className="h-10 w-48 mb-8 rounded-xl" />
        <Skeleton className="h-24 w-full mb-12 rounded-2xl" />
        <div className="space-y-12">
          <Skeleton className="h-[600px] w-full rounded-[2rem]" />
          <div className="grid md:grid-cols-2 gap-8">
            <Skeleton className="h-[400px] rounded-3xl" />
            <Skeleton className="h-[400px] rounded-3xl" />
          </div>
        </div>
      </div>
    );
  }

  if (isError || !session) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-center px-4">
        <AlertCircle className="w-16 h-16 text-destructive mb-4" />
        <h2 className="text-2xl font-bold mb-2">Recommendation Not Found</h2>
        <p className="text-muted-foreground mb-6">We couldn't find this recommendation session.</p>
        <Link href="/recommend">
          <Button className="rounded-full">Start New Session</Button>
        </Link>
      </div>
    );
  }

  const topPick = session.products[0];
  const alternatives = session.products.slice(1);

  return (
    <div className="container mx-auto px-4 py-8 md:py-12 max-w-6xl pb-24">
      <div className="flex items-center gap-4 mb-8">
        <Link href="/history">
          <Button variant="ghost" size="icon" className="rounded-full">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Your Results</h1>
      </div>

      {/* Summary Card */}
      <div className="bg-primary/10 border-2 border-primary/20 rounded-3xl p-6 md:p-8 mb-12 flex gap-6 items-start relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none" />
        <div className="bg-primary p-3 rounded-2xl shrink-0 text-primary-foreground shadow-lg shadow-primary/30 z-10 hidden md:block">
          <Sparkles className="w-6 h-6" />
        </div>
        <div className="z-10">
          <h2 className="text-xl font-bold text-primary mb-2">Why we picked these</h2>
          <p className="text-lg leading-relaxed text-foreground/90">{session.summary}</p>
        </div>
      </div>

      {/* Top Pick */}
      {topPick && (
        <div className="mb-16 animate-in fade-in slide-in-from-bottom-8 duration-700">
          <div className="flex items-center gap-4 mb-6">
            <Badge className="bg-accent hover:bg-accent/90 text-accent-foreground px-4 py-1.5 text-sm uppercase tracking-wider font-bold rounded-full border-none shadow-[0_0_15px_-3px_hsl(var(--accent))]">
              Top Pick
            </Badge>
            <h2 className="text-3xl font-black">{topPick.name}</h2>
          </div>

          <div className="bg-card border border-border/60 rounded-[2.5rem] p-6 md:p-10 shadow-2xl overflow-hidden relative group">
            
            <div className="grid md:grid-cols-2 gap-10">
              {/* Product Image & Score */}
              <div className="relative flex flex-col items-center justify-center p-8 bg-white rounded-[2rem] border border-border/50">
                {/* Match Score Badge */}
                <div className="absolute -top-4 -right-4 w-24 h-24 bg-primary text-primary-foreground rounded-full flex flex-col items-center justify-center shadow-lg shadow-primary/40 z-20 border-4 border-card rotate-12 group-hover:rotate-0 transition-transform duration-500">
                  <span className="text-3xl font-black leading-none">{topPick.matchScore}%</span>
                  <span className="text-[10px] uppercase font-bold tracking-wider opacity-80">Match</span>
                </div>
                
                <img 
                  src={topPick.imageUrl} 
                  alt={topPick.name} 
                  className="w-full max-w-[300px] object-contain mix-blend-darken hover:scale-105 transition-transform duration-500"
                />
              </div>

              {/* Product Details */}
              <div className="flex flex-col">
                <div className="mb-6 pb-6 border-b border-border/60">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-bold text-muted-foreground">{topPick.brand}</span>
                    <span className="text-muted-foreground">•</span>
                    <span className="text-primary font-bold flex items-center gap-1"><Star fill="currentColor" className="w-4 h-4" /> {topPick.rating}</span>
                    <span className="text-xs text-muted-foreground">({topPick.reviewCount} reviews)</span>
                  </div>
                  <div className="text-4xl font-mono font-black mb-4">
                    ${topPick.price}
                  </div>
                  <p className="text-lg bg-muted/50 p-4 rounded-xl border border-border/50 italic text-foreground/80">
                    "{topPick.matchReason}"
                  </p>
                </div>

                <div className="grid sm:grid-cols-2 gap-8 mb-8 flex-1">
                  <div>
                    <h4 className="font-bold mb-3 flex items-center gap-2 text-emerald-600 dark:text-emerald-400">
                      <CheckCircle2 className="w-5 h-5" /> Pros
                    </h4>
                    <ul className="space-y-2">
                      {topPick.pros.map((pro, i) => (
                        <li key={i} className="text-sm flex items-start gap-2">
                          <span className="text-emerald-500 mt-0.5">•</span> {pro}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-bold mb-3 flex items-center gap-2 text-rose-600 dark:text-rose-400">
                      <XCircle className="w-5 h-5" /> Cons
                    </h4>
                    <ul className="space-y-2">
                      {topPick.cons.map((con, i) => (
                        <li key={i} className="text-sm flex items-start gap-2">
                          <span className="text-rose-500 mt-0.5">•</span> {con}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Buy Options */}
                <div className="space-y-3 mt-auto">
                  <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Where to Buy</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {topPick.buyOptions.map((opt, i) => (
                      <a 
                        key={i} 
                        href={opt.url} 
                        target="_blank" 
                        rel="noreferrer"
                        className="block"
                      >
                        <Button 
                          className={`w-full h-14 rounded-xl font-bold flex justify-between items-center px-4 ${getStoreColor(opt.platform)} border-none shadow-md hover:shadow-lg transition-all`}
                        >
                          <span className="flex items-center gap-2">
                            {getStoreIcon(opt.platform)}
                            {opt.platform}
                          </span>
                          <span className="font-mono text-lg">${opt.price}</span>
                        </Button>
                      </a>
                    ))}
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      )}

      {/* Alternatives */}
      {alternatives.length > 0 && (
        <div className="space-y-6">
          <h3 className="text-2xl font-bold mb-6">Also Great Alternatives</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {alternatives.map((product, idx) => (
              <div key={product.id} className="bg-card border border-border/60 rounded-3xl p-6 flex flex-col hover:border-primary/40 transition-colors duration-300 shadow-sm hover:shadow-md delay-100 animate-in fade-in slide-in-from-bottom-8" style={{ animationFillMode: 'both', animationDelay: `${(idx + 1) * 150}ms` }}>
                <div className="flex gap-6 mb-6">
                  <div className="w-32 h-32 shrink-0 bg-white rounded-2xl p-4 flex items-center justify-center border border-border/50 relative">
                    <div className="absolute -top-3 -right-3 w-10 h-10 bg-secondary text-secondary-foreground rounded-full flex items-center justify-center text-sm font-bold shadow-md border-2 border-card">
                      {product.matchScore}%
                    </div>
                    <img src={product.imageUrl} alt={product.name} className="w-full h-full object-contain mix-blend-darken" />
                  </div>
                  <div className="flex flex-col justify-center">
                    <Badge variant="outline" className="w-fit mb-2 text-xs">{product.brand}</Badge>
                    <h3 className="font-bold text-lg leading-tight mb-2 line-clamp-2">{product.name}</h3>
                    <div className="text-2xl font-mono font-bold text-primary">${product.price}</div>
                  </div>
                </div>
                
                <p className="text-sm text-muted-foreground mb-6 line-clamp-2">
                  {product.matchReason}
                </p>
                
                <div className="mt-auto flex flex-col gap-2">
                  {product.buyOptions.slice(0, 2).map((opt, i) => (
                    <a key={i} href={opt.url} target="_blank" rel="noreferrer">
                      <Button variant="outline" className="w-full justify-between h-12 rounded-xl group hover:border-primary/50">
                        <span className="flex items-center gap-2">
                          <span className="text-muted-foreground group-hover:text-foreground transition-colors">{opt.platform}</span>
                        </span>
                        <span className="font-mono font-semibold">${opt.price} <ExternalLink className="w-3 h-3 inline ml-1 opacity-50" /></span>
                      </Button>
                    </a>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
