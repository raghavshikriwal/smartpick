import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { AlertCircle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
      <div className="w-20 h-20 bg-destructive/10 text-destructive rounded-full flex items-center justify-center mb-6">
        <AlertCircle className="w-10 h-10" />
      </div>
      <h1 className="text-4xl font-black mb-4 tracking-tight">404 - Not Found</h1>
      <p className="text-muted-foreground text-lg mb-8 max-w-md">
        The page or product you're looking for doesn't exist or has been moved.
      </p>
      <Link href="/">
        <Button size="lg" className="rounded-full px-8">
          Return Home
        </Button>
      </Link>
    </div>
  );
}
