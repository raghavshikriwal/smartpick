import { Link } from "wouter";
import { ArrowRight, Cpu, Smartphone, Laptop, Tv, Camera, Headphones, Gamepad, Watch } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useListCategories, useGetTrendingProducts } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";

// Map string icon names to Lucide components
const IconMap: Record<string, any> = {
  Smartphone,
  Laptop,
  Tv,
  Camera,
  Headphones,
  Gamepad,
  Watch,
  Cpu
};

export default function Home() {
  const { data: categories, isLoading: isLoadingCategories } = useListCategories();
  const { data: trendingProducts, isLoading: isLoadingTrending } = useGetTrendingProducts();

  return (
    <div className="w-full flex flex-col pb-20">
      {/* Hero Section */}
      <section className="relative pt-24 pb-32 overflow-hidden flex flex-col items-center justify-center text-center px-4">
        {/* Abstract Background Elements */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/20 rounded-full blur-3xl opacity-50 mix-blend-multiply pointer-events-none" />
        <div className="absolute top-1/3 left-1/3 w-[600px] h-[600px] bg-secondary/20 rounded-full blur-3xl opacity-50 mix-blend-multiply pointer-events-none" />
        <div className="absolute top-2/3 right-1/3 w-[500px] h-[500px] bg-accent/20 rounded-full blur-3xl opacity-50 mix-blend-multiply pointer-events-none" />
        
        <Badge variant="outline" className="mb-8 px-4 py-1.5 text-sm rounded-full bg-background/50 backdrop-blur border-primary/20 text-primary font-medium tracking-wide">
          <span className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            Premium Electronics Advisor
          </span>
        </Badge>
        
        <h1 className="text-5xl md:text-7xl font-black max-w-4xl tracking-tight leading-[1.1] mb-6">
          Find your perfect tech. <br />
          <span className="text-gradient">Zero guesswork.</span>
        </h1>
        
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mb-10 leading-relaxed">
          Tell us what you need, your budget, and how you'll use it. 
          We'll analyze thousands of specs to find your absolute best match.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center gap-4 z-10">
          <Link href="/recommend">
            <Button size="lg" className="rounded-full h-14 px-8 text-lg shadow-[0_0_40px_-10px_hsl(var(--primary))] hover:shadow-[0_0_60px_-10px_hsl(var(--primary))] transition-all duration-500 font-semibold gap-2">
              Start Finding
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
          <Link href="/history">
            <Button size="lg" variant="secondary" className="rounded-full h-14 px-8 text-lg font-semibold bg-white/50 backdrop-blur dark:bg-black/50 border border-border/50 hover:bg-white/80 dark:hover:bg-black/80 transition-all duration-300">
              View Past Picks
            </Button>
          </Link>
        </div>
      </section>

      {/* Categories Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="flex flex-col items-center mb-12 text-center">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">What are you looking for?</h2>
          <p className="text-muted-foreground max-w-xl">Select a category to start your personalized recommendation journey.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 max-w-5xl mx-auto">
          {isLoadingCategories ? (
            Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="h-40 rounded-3xl" />
            ))
          ) : (
            categories?.map((cat) => {
              const Icon = IconMap[cat.icon] || Cpu;
              return (
                <Link key={cat.id} href={`/recommend?category=${cat.id}`}>
                  <div className="group cursor-pointer flex flex-col items-center justify-center p-6 h-40 bg-card rounded-3xl border border-border hover:border-primary/50 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                    <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mb-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
                      <Icon className="w-8 h-8" />
                    </div>
                    <span className="font-semibold">{cat.name}</span>
                  </div>
                </Link>
              );
            })
          )}
        </div>
      </section>

      {/* Trending Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="flex items-center justify-between mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-2">Trending Now</h2>
            <p className="text-muted-foreground">The most recommended gear this week.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {isLoadingTrending ? (
            Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex flex-col gap-4">
                <Skeleton className="h-64 rounded-3xl" />
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            ))
          ) : (
            trendingProducts?.slice(0, 3).map((product) => (
              <div key={product.id} className="group flex flex-col bg-card rounded-3xl border border-border overflow-hidden hover:shadow-2xl hover:border-primary/30 transition-all duration-500">
                <div className="aspect-[4/3] bg-white p-8 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-t from-black/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10" />
                  <img 
                    src={product.imageUrl} 
                    alt={product.name} 
                    className="w-full h-full object-contain mix-blend-darken group-hover:scale-105 transition-transform duration-700 ease-out" 
                  />
                  <div className="absolute top-4 right-4 z-20">
                    <Badge variant="secondary" className="bg-background/80 backdrop-blur-md font-semibold">
                      {product.brand}
                    </Badge>
                  </div>
                </div>
                <div className="p-6 flex flex-col flex-1">
                  <div className="flex justify-between items-start mb-2 gap-4">
                    <h3 className="font-bold text-lg leading-tight line-clamp-2">{product.name}</h3>
                    <span className="font-mono font-bold text-lg text-primary whitespace-nowrap">
                      ${product.price}
                    </span>
                  </div>
                  <div className="mt-auto pt-4 flex gap-2 flex-wrap">
                    {Object.entries(product.specs).slice(0, 2).map(([k, v]) => (
                      <Badge key={k} variant="outline" className="text-xs bg-muted/50 text-muted-foreground border-none">
                        {v}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </section>

      {/* How it works */}
      <section className="bg-primary/5 py-24 mt-10">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">How SmartPick Works</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 max-w-5xl mx-auto">
            {[
              { num: "01", title: "Tell us your needs", desc: "Select category, set your budget, and describe how you plan to use the device." },
              { num: "02", title: "Smart analysis", desc: "Our engine analyzes thousands of specs and reviews to find your perfect match." },
              { num: "03", title: "Get the best deal", desc: "We show you why it's a match and where to buy it at the best price right now." }
            ].map((step, i) => (
              <div key={i} className="flex flex-col items-center text-center relative">
                {i !== 2 && (
                  <div className="hidden md:block absolute top-10 left-[60%] w-full h-[2px] bg-gradient-to-r from-primary/30 to-transparent" />
                )}
                <div className="w-20 h-20 rounded-full bg-background border-2 border-primary/20 flex items-center justify-center text-2xl font-black font-mono text-primary mb-6 shadow-[0_0_30px_-5px_hsl(var(--primary))] z-10">
                  {step.num}
                </div>
                <h3 className="text-xl font-bold mb-3">{step.title}</h3>
                <p className="text-muted-foreground">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
