import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { ArrowLeft, ArrowRight, Cpu, Smartphone, Laptop, Tv, Camera, Headphones, Gamepad, Watch, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { useListCategories, useCreateRecommendation } from "@workspace/api-client-react";

const IconMap: Record<string, any> = {
  Smartphone, Laptop, Tv, Camera, Headphones, Gamepad, Watch, Cpu
};

const commonUseCases = [
  "Gaming", "Content Creation", "Office Work", "Student / School", "Travel", "Fitness", "Casual / Media Consumption"
];

const wizardSchema = z.object({
  category: z.string().min(1, "Please select a category"),
  budget: z.coerce.number().min(1, "Budget must be greater than 0"),
  currency: z.string().default("USD"),
  useCase: z.string().min(1, "Please tell us how you'll use it"),
  preferences: z.array(z.string()).default([]),
  brandPreferences: z.array(z.string()).default([]),
  additionalNotes: z.string().optional()
});

type WizardData = z.infer<typeof wizardSchema>;

export default function Wizard() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const totalSteps = 4;
  
  const { data: categories, isLoading: isLoadingCats } = useListCategories();
  const createMutation = useCreateRecommendation();

  // Extract category from URL if present
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const catId = params.get('category');
    if (catId && categories?.find(c => c.id === catId)) {
      form.setValue('category', catId);
      setStep(2);
    }
  }, [categories]);

  const form = useForm<WizardData>({
    resolver: zodResolver(wizardSchema),
    defaultValues: {
      category: "",
      budget: 1000,
      currency: "USD",
      useCase: "",
      preferences: [],
      brandPreferences: [],
      additionalNotes: ""
    }
  });

  const categoryValue = form.watch("category");
  const useCaseValue = form.watch("useCase");

  const handleNext = async () => {
    let isValid = false;
    
    if (step === 1) isValid = await form.trigger("category");
    if (step === 2) isValid = await form.trigger("budget");
    if (step === 3) isValid = await form.trigger("useCase");
    
    if (isValid) {
      setStep(s => Math.min(totalSteps, s + 1));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleBack = () => {
    setStep(s => Math.max(1, s - 1));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const onSubmit = (data: WizardData) => {
    createMutation.mutate({ data }, {
      onSuccess: (session) => {
        setLocation(`/results/${session.id}`);
      }
    });
  };

  // Determine transition direction class based on state (simplified approach)
  const isSubmitting = createMutation.isPending;

  return (
    <div className="flex flex-col items-center py-12 px-4 max-w-4xl mx-auto w-full min-h-[80vh]">
      
      {/* Progress Header */}
      <div className="w-full mb-12 flex flex-col gap-4">
        <div className="flex justify-between items-center text-sm font-medium text-muted-foreground">
          <button 
            onClick={handleBack} 
            disabled={step === 1 || isSubmitting}
            className="flex items-center gap-1 hover:text-foreground disabled:opacity-30 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Back
          </button>
          <span>Step {step} of {totalSteps}</span>
        </div>
        <Progress value={(step / totalSteps) * 100} className="h-2 rounded-full bg-secondary/20" />
        <div className="flex justify-between text-xs font-semibold text-muted-foreground px-1 mt-1">
          <span className={step >= 1 ? "text-primary" : ""}>Category</span>
          <span className={step >= 2 ? "text-primary" : ""}>Budget</span>
          <span className={step >= 3 ? "text-primary" : ""}>Use Case</span>
          <span className={step >= 4 ? "text-primary" : ""}>Details</span>
        </div>
      </div>

      {/* Main Form Area */}
      <div className="w-full bg-card rounded-[2rem] border border-border/50 shadow-xl shadow-primary/5 p-6 md:p-10">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            
            {/* STEP 1: Category */}
            {step === 1 && (
              <div className="space-y-8 animate-in fade-in slide-in-from-right-8 duration-500">
                <div className="text-center space-y-2">
                  <h1 className="text-3xl md:text-4xl font-bold tracking-tight">What are you looking for?</h1>
                  <p className="text-muted-foreground text-lg">Select a device category to get started.</p>
                </div>
                
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem className="space-y-4">
                      <FormControl>
                        <RadioGroup
                          onValueChange={(val) => {
                            field.onChange(val);
                            // Auto advance on category select
                            setTimeout(handleNext, 300);
                          }}
                          defaultValue={field.value}
                          className="grid grid-cols-2 md:grid-cols-4 gap-4"
                        >
                          {isLoadingCats ? (
                            <div className="col-span-full text-center py-10">Loading categories...</div>
                          ) : (
                            categories?.map((cat) => {
                              const Icon = IconMap[cat.icon] || Cpu;
                              const isSelected = field.value === cat.id;
                              return (
                                <FormItem key={cat.id}>
                                  <FormControl>
                                    <RadioGroupItem value={cat.id} className="sr-only" />
                                  </FormControl>
                                  <Label
                                    className={`flex flex-col items-center justify-center p-6 h-36 rounded-2xl border-2 cursor-pointer transition-all duration-300 ${
                                      isSelected 
                                        ? "border-primary bg-primary/5 text-primary" 
                                        : "border-border bg-background hover:border-primary/40 hover:bg-muted/50 text-foreground"
                                    }`}
                                  >
                                    <Icon className={`w-8 h-8 mb-3 ${isSelected ? "text-primary" : "text-muted-foreground"}`} />
                                    <span className="font-semibold">{cat.name}</span>
                                  </Label>
                                </FormItem>
                              );
                            })
                          )}
                        </RadioGroup>
                      </FormControl>
                      <FormMessage className="text-center mt-4" />
                    </FormItem>
                  )}
                />
              </div>
            )}

            {/* STEP 2: Budget */}
            {step === 2 && (
              <div className="space-y-8 animate-in fade-in slide-in-from-right-8 duration-500">
                <div className="text-center space-y-2">
                  <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Set your budget</h1>
                  <p className="text-muted-foreground text-lg">How much are you willing to spend on your new {categories?.find(c => c.id === categoryValue)?.name?.toLowerCase() || 'device'}?</p>
                </div>
                
                <div className="max-w-md mx-auto space-y-8">
                  <FormField
                    control={form.control}
                    name="budget"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="sr-only">Budget</FormLabel>
                        <FormControl>
                          <div className="relative flex items-center">
                            <span className="absolute left-6 text-2xl font-mono text-muted-foreground">$</span>
                            <Input 
                              type="number" 
                              {...field} 
                              className="text-4xl h-24 pl-12 font-mono font-bold rounded-2xl bg-muted/30 border-2 border-border focus-visible:border-primary focus-visible:ring-primary/20 text-center"
                            />
                          </div>
                        </FormControl>
                        <FormMessage className="text-center" />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex gap-3 justify-center flex-wrap">
                    {[500, 1000, 1500, 2000, 3000].map(preset => (
                      <Badge 
                        key={preset} 
                        variant="secondary" 
                        className="text-sm px-4 py-2 cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors"
                        onClick={() => form.setValue("budget", preset)}
                      >
                        ${preset}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* STEP 3: Use Case */}
            {step === 3 && (
              <div className="space-y-8 animate-in fade-in slide-in-from-right-8 duration-500">
                <div className="text-center space-y-2">
                  <h1 className="text-3xl md:text-4xl font-bold tracking-tight">How will you use it?</h1>
                  <p className="text-muted-foreground text-lg">Help us understand your primary needs.</p>
                </div>
                
                <FormField
                  control={form.control}
                  name="useCase"
                  render={({ field }) => (
                    <FormItem className="max-w-xl mx-auto">
                      <FormControl>
                        <div className="space-y-4">
                          <div className="flex flex-wrap gap-3 mb-6">
                            {commonUseCases.map(uc => (
                              <Badge 
                                key={uc}
                                variant="outline"
                                className={`text-sm px-4 py-2 cursor-pointer transition-colors border-2 ${
                                  useCaseValue === uc 
                                    ? "border-primary bg-primary/10 text-primary" 
                                    : "border-border hover:border-primary/40"
                                }`}
                                onClick={() => field.onChange(uc)}
                              >
                                {uc}
                              </Badge>
                            ))}
                          </div>
                          
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-muted-foreground">
                              <span className="text-sm font-medium">Or type here:</span>
                            </div>
                            <Input 
                              placeholder="e.g., Video editing and light gaming" 
                              className="pl-28 h-14 rounded-xl text-md"
                              value={field.value}
                              onChange={field.onChange}
                            />
                          </div>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            )}

            {/* STEP 4: Preferences & Details */}
            {step === 4 && (
              <div className="space-y-8 animate-in fade-in slide-in-from-right-8 duration-500">
                <div className="text-center space-y-2">
                  <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Final Details</h1>
                  <p className="text-muted-foreground text-lg">Any specific brand preferences or must-have features?</p>
                </div>
                
                <div className="max-w-xl mx-auto space-y-6">
                  {/* Brand Preferences */}
                  <FormField
                    control={form.control}
                    name="brandPreferences"
                    render={({ field }) => {
                      const brands = ["Apple", "Samsung", "Google", "Sony", "Dell", "HP", "Lenovo", "ASUS", "OnePlus", "Bose"];
                      return (
                        <FormItem>
                          <FormLabel className="text-base font-semibold">Preferred Brands (Optional)</FormLabel>
                          <FormControl>
                            <div className="flex flex-wrap gap-3 mt-2">
                              {brands.map(brand => {
                                const isSelected = (field.value || []).includes(brand);
                                return (
                                  <Badge
                                    key={brand}
                                    variant="outline"
                                    className={`text-sm px-4 py-2 cursor-pointer transition-all border-2 select-none ${
                                      isSelected
                                        ? "border-primary bg-primary/10 text-primary font-semibold"
                                        : "border-border hover:border-primary/40"
                                    }`}
                                    onClick={() => {
                                      const current = field.value || [];
                                      field.onChange(
                                        isSelected ? current.filter(b => b !== brand) : [...current, brand]
                                      );
                                    }}
                                  >
                                    {brand}
                                  </Badge>
                                );
                              })}
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      );
                    }}
                  />

                  {/* Feature Preferences */}
                  <FormField
                    control={form.control}
                    name="preferences"
                    render={({ field }) => {
                      const featureTags = ["Long battery", "Lightweight", "OLED display", "5G", "Fast charging", "Premium build", "Good camera", "Gaming performance", "Value for money"];
                      return (
                        <FormItem>
                          <FormLabel className="text-base font-semibold">Must-Have Features (Optional)</FormLabel>
                          <FormControl>
                            <div className="flex flex-wrap gap-3 mt-2">
                              {featureTags.map(tag => {
                                const isSelected = (field.value || []).includes(tag);
                                return (
                                  <Badge
                                    key={tag}
                                    variant="outline"
                                    className={`text-sm px-4 py-2 cursor-pointer transition-all border-2 select-none ${
                                      isSelected
                                        ? "border-accent bg-accent/10 text-accent-foreground font-semibold"
                                        : "border-border hover:border-accent/40"
                                    }`}
                                    onClick={() => {
                                      const current = field.value || [];
                                      field.onChange(
                                        isSelected ? current.filter(t => t !== tag) : [...current, tag]
                                      );
                                    }}
                                  >
                                    {tag}
                                  </Badge>
                                );
                              })}
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      );
                    }}
                  />

                  <FormField
                    control={form.control}
                    name="additionalNotes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-base font-semibold">Anything Else? (Optional)</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="e.g., I travel frequently, need USB-C charging, no budget for accessories..." 
                            className="resize-none h-28 rounded-xl"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {isSubmitting && (
                    <div className="flex flex-col items-center justify-center p-8 text-center animate-pulse">
                      <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mb-4">
                        <Sparkles className="w-8 h-8 text-primary animate-spin" />
                      </div>
                      <h3 className="text-xl font-bold text-primary">Analyzing Specs...</h3>
                      <p className="text-sm text-muted-foreground mt-2">Finding your perfect match</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Footer Navigation */}
            <div className="flex justify-between items-center pt-8 border-t border-border/50 mt-8">
              {step > 1 ? (
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={handleBack}
                  disabled={isSubmitting}
                  className="rounded-full px-6"
                >
                  Previous
                </Button>
              ) : <div></div>}
              
              {step < totalSteps ? (
                <Button 
                  type="button" 
                  onClick={handleNext} 
                  className="rounded-full px-8 ml-auto font-semibold"
                >
                  Next Step <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              ) : (
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="rounded-full px-8 h-12 text-lg shadow-[0_0_20px_-5px_hsl(var(--primary))] font-bold"
                >
                  {isSubmitting ? "Finding Best Options..." : "Find My Match"} 
                  {!isSubmitting && <Sparkles className="w-4 h-4 ml-2" />}
                </Button>
              )}
            </div>

          </form>
        </Form>
      </div>
    </div>
  );
}
