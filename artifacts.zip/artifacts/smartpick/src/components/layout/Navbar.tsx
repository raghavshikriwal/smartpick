import { Link, useLocation } from "wouter";
import { Zap, History, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Navbar() {
  const [location] = useLocation();

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-xl">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <div className="bg-primary/10 p-2 rounded-xl group-hover:bg-primary/20 transition-colors">
            <Zap className="w-5 h-5 text-primary" />
          </div>
          <span className="font-bold text-xl tracking-tight">SmartPick</span>
        </Link>
        
        <nav className="flex items-center gap-6">
          <Link 
            href="/history" 
            className={`text-sm font-medium transition-colors hover:text-primary ${
              location === "/history" ? "text-primary" : "text-muted-foreground"
            }`}
          >
            <span className="flex items-center gap-2">
              <History className="w-4 h-4" />
              History
            </span>
          </Link>
          
          <Button asChild className="rounded-full font-semibold px-6 shadow-md hover:shadow-primary/25 transition-all duration-300 gap-2">
            <Link href="/recommend">
              <Sparkles className="w-4 h-4" />
              Find My Tech
            </Link>
          </Button>
        </nav>
      </div>
    </header>
  );
}
