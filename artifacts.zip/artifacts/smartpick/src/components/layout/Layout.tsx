import { ReactNode } from "react";
import { Navbar } from "./Navbar";
import { Zap } from "lucide-react";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-[100dvh] flex flex-col bg-background selection:bg-primary/30">
      <Navbar />
      <main className="flex-1 flex flex-col w-full">
        {children}
      </main>
      <footer className="border-t border-border/40 py-8 mt-auto bg-background/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 text-center text-muted-foreground text-sm">
          <p className="flex items-center justify-center gap-1 font-medium">
            <Zap className="w-4 h-4 text-primary" fill="currentColor" /> SmartPick &copy; {new Date().getFullYear()}
          </p>
        </div>
      </footer>
    </div>
  );
}
