import { Router, type IRouter } from "express";
import { db, recommendationSessionsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import {
  CreateRecommendationBody,
  GetRecommendationParams,
  DeleteRecommendationParams,
  GetTrendingProductsQueryParams,
} from "@workspace/api-zod";
import { getTrendingProducts, getProductsByCategory, getAllProducts } from "../lib/product-catalog.js";
import { generateRecommendations, generateSummary } from "../lib/recommendation-engine.js";

const router: IRouter = Router();

// GET /categories
router.get("/categories", async (_req, res): Promise<void> => {
  res.json([
    { id: "smartphone", name: "Smartphones", icon: "Smartphone", description: "iOS and Android phones" },
    { id: "laptop", name: "Laptops", icon: "Laptop", description: "Notebooks and ultrabooks" },
    { id: "tablet", name: "Tablets", icon: "Tablet", description: "iPads and Android tablets" },
    { id: "headphones", name: "Headphones", icon: "Headphones", description: "Earbuds and over-ear headphones" },
    { id: "smartwatch", name: "Smartwatches", icon: "Watch", description: "Wearables and fitness trackers" },
    { id: "camera", name: "Cameras", icon: "Camera", description: "Mirrorless, DSLR and compact cameras" },
    { id: "gaming", name: "Gaming", icon: "Gamepad2", description: "Consoles and gaming accessories" },
    { id: "tv", name: "TVs", icon: "Tv", description: "Smart TVs and home theater" },
  ]);
});

// GET /trending
router.get("/trending", async (req, res): Promise<void> => {
  const parsed = GetTrendingProductsQueryParams.safeParse(req.query);
  const category = parsed.success ? parsed.data.category : undefined;
  const limit = parsed.success && parsed.data.limit ? parsed.data.limit : 8;

  const products = getTrendingProducts(category, limit).map(p => ({
    ...p,
    matchScore: 0,
    matchReason: "",
  }));
  res.json(products);
});

// GET /recommendations
router.get("/recommendations", async (req, res): Promise<void> => {
  const sessions = await db
    .select()
    .from(recommendationSessionsTable)
    .orderBy(desc(recommendationSessionsTable.createdAt))
    .limit(20);

  const mapped = sessions.map(s => ({
    id: s.id,
    category: s.category,
    budget: Number(s.budget),
    currency: s.currency,
    useCase: s.useCase,
    preferences: (s.preferences as string[]) || [],
    brandPreferences: (s.brandPreferences as string[]) || [],
    location: s.location,
    additionalNotes: s.additionalNotes,
    products: s.products as unknown[],
    summary: s.summary,
    createdAt: s.createdAt.toISOString(),
  }));

  res.json(mapped);
});

// POST /recommendations
router.post("/recommendations", async (req, res): Promise<void> => {
  const parsed = CreateRecommendationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const {
    category,
    budget,
    currency,
    useCase,
    preferences = [],
    brandPreferences = [],
    location,
    additionalNotes,
  } = parsed.data;

  const products = generateRecommendations({
    category,
    budget,
    currency,
    useCase,
    preferences,
    brandPreferences,
    location,
    additionalNotes,
  });

  const summary = generateSummary(
    { category, budget, currency, useCase, preferences, brandPreferences, location, additionalNotes },
    products
  );

  const [session] = await db
    .insert(recommendationSessionsTable)
    .values({
      category,
      budget: String(budget),
      currency,
      useCase,
      preferences: preferences as string[],
      brandPreferences: brandPreferences as string[],
      location: location ?? null,
      additionalNotes: additionalNotes ?? null,
      products: products as unknown as never[],
      summary,
    })
    .returning();

  res.status(201).json({
    id: session.id,
    category: session.category,
    budget: Number(session.budget),
    currency: session.currency,
    useCase: session.useCase,
    preferences: (session.preferences as string[]) || [],
    brandPreferences: (session.brandPreferences as string[]) || [],
    location: session.location,
    additionalNotes: session.additionalNotes,
    products,
    summary: session.summary,
    createdAt: session.createdAt.toISOString(),
  });
});

// GET /recommendations/:id
router.get("/recommendations/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const parsed = GetRecommendationParams.safeParse({ id: parseInt(raw, 10) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const [session] = await db
    .select()
    .from(recommendationSessionsTable)
    .where(eq(recommendationSessionsTable.id, parsed.data.id));

  if (!session) {
    res.status(404).json({ error: "Recommendation not found" });
    return;
  }

  res.json({
    id: session.id,
    category: session.category,
    budget: Number(session.budget),
    currency: session.currency,
    useCase: session.useCase,
    preferences: (session.preferences as string[]) || [],
    brandPreferences: (session.brandPreferences as string[]) || [],
    location: session.location,
    additionalNotes: session.additionalNotes,
    products: session.products as unknown[],
    summary: session.summary,
    createdAt: session.createdAt.toISOString(),
  });
});

// DELETE /recommendations/:id
router.delete("/recommendations/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const parsed = DeleteRecommendationParams.safeParse({ id: parseInt(raw, 10) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }

  const [deleted] = await db
    .delete(recommendationSessionsTable)
    .where(eq(recommendationSessionsTable.id, parsed.data.id))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Recommendation not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
