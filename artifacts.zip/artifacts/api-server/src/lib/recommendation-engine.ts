import type { Product } from "./product-catalog.js";
import { getAllProducts } from "./product-catalog.js";

export interface RecommendationRequest {
  category: string;
  budget: number;
  currency: string;
  useCase: string;
  preferences?: string[];
  brandPreferences?: string[];
  location?: string;
  additionalNotes?: string;
}

interface ScoredProduct extends Omit<Product, "matchScore" | "matchReason"> {
  matchScore: number;
  matchReason: string;
}

/**
 * Smart rule-based recommendation engine.
 * Scores products across multiple dimensions and returns the best matches.
 */
export function generateRecommendations(req: RecommendationRequest, maxResults = 5): ScoredProduct[] {
  const allProducts = getAllProducts();

  // Filter by category
  const categoryProducts = allProducts.filter(p => {
    const cat = p.category.toLowerCase();
    const reqCat = req.category.toLowerCase();
    // Handle aliases
    if (reqCat === "phone" || reqCat === "mobile") return cat === "smartphone";
    if (reqCat === "earphone" || reqCat === "earbuds" || reqCat === "audio") return cat === "headphones";
    if (reqCat === "console") return cat === "gaming";
    return cat === reqCat;
  });

  if (categoryProducts.length === 0) return [];

  const scored = categoryProducts.map(product => {
    let score = 0;
    const reasons: string[] = [];

    // ── BUDGET SCORING (0–35 points) ───────────────────────────
    const budgetRatio = product.price / req.budget;
    if (budgetRatio <= 0.7) {
      score += 25;
      reasons.push(`Well within your ₹/$ ${req.budget.toLocaleString()} budget`);
    } else if (budgetRatio <= 0.9) {
      score += 35;
      reasons.push(`Excellent value at ${Math.round(budgetRatio * 100)}% of your budget`);
    } else if (budgetRatio <= 1.0) {
      score += 28;
      reasons.push(`Fits your budget perfectly`);
    } else if (budgetRatio <= 1.15) {
      score += 15;
      reasons.push(`Slightly above budget but worth the extra spend`);
    } else {
      score += 0; // Over budget
    }

    // ── USE CASE SCORING (0–30 points) ─────────────────────────
    const useCase = req.useCase.toLowerCase();
    const useCaseMatches = product.useCases.filter(uc => {
      const ucLower = uc.toLowerCase();
      return (
        useCase.includes(ucLower) ||
        ucLower.includes(useCase) ||
        aliasMatch(useCase, ucLower)
      );
    });

    const tagMatches = product.tags.filter(tag => {
      const tagLower = tag.toLowerCase();
      return useCase.includes(tagLower) || tagLower.includes(useCase.split(" ")[0]);
    });

    const useCaseScore = Math.min(30, useCaseMatches.length * 15 + tagMatches.length * 5);
    score += useCaseScore;
    if (useCaseMatches.length > 0) {
      reasons.push(`Great for ${useCaseMatches[0].replace(/-/g, " ")}`);
    }

    // ── PREFERENCES SCORING (0–15 points) ──────────────────────
    const prefs = (req.preferences || []).map(p => p.toLowerCase());
    const prefMatches = prefs.filter(pref =>
      product.tags.some(t => t.includes(pref) || pref.includes(t)) ||
      product.specs && Object.values(product.specs).some(v => v.toLowerCase().includes(pref))
    );
    score += Math.min(15, prefMatches.length * 8);
    if (prefMatches.length > 0) {
      reasons.push(`Matches your preference for ${prefMatches[0]}`);
    }

    // ── BRAND PREFERENCE SCORING (0–10 points) ─────────────────
    const brandPrefs = (req.brandPreferences || []).map(b => b.toLowerCase());
    if (brandPrefs.length > 0 && brandPrefs.some(b => product.brand.toLowerCase().includes(b))) {
      score += 10;
      reasons.push(`Your preferred brand`);
    }

    // ── RATING QUALITY BONUS (0–10 points) ─────────────────────
    const ratingBonus = Math.round((product.rating - 4.0) * 20);
    score += Math.max(0, Math.min(10, ratingBonus));
    if (product.rating >= 4.7) {
      reasons.push(`Highly rated (${product.rating}/5 from ${product.reviewCount.toLocaleString()} reviews)`);
    }

    // Normalize to 0–100
    const normalizedScore = Math.min(100, Math.max(0, score));

    // Build match reason string from top reasons
    const matchReason = reasons.length > 0
      ? reasons.slice(0, 2).join(". ") + "."
      : `Solid pick for your ${req.useCase} needs.`;

    return { ...product, matchScore: normalizedScore, matchReason };
  });

  // Sort by match score descending, filter out hopeless matches
  return scored
    .filter(p => p.matchScore > 10)
    .sort((a, b) => b.matchScore - a.matchScore)
    .slice(0, maxResults);
}

/**
 * Generate a natural language summary for the recommendation session.
 */
export function generateSummary(req: RecommendationRequest, products: ScoredProduct[]): string {
  if (products.length === 0) {
    return `We couldn't find products matching your exact criteria. Try adjusting your budget or category.`;
  }

  const top = products[0];
  const budgetNote = req.budget ? ` within a ${req.currency} ${req.budget.toLocaleString()} budget` : "";
  const useCaseNote = req.useCase ? ` for ${req.useCase}` : "";

  return `Based on your requirements${useCaseNote}${budgetNote}, we found ${products.length} great ${req.category} options. Our top pick is the ${top.brand} ${top.name} with a ${top.matchScore}% match score. ${top.matchReason}`;
}

function aliasMatch(useCase: string, uc: string): boolean {
  const aliases: Record<string, string[]> = {
    work: ["professional", "business", "programming", "productivity"],
    study: ["student", "everyday", "home-office"],
    travel: ["commute", "portable", "ultralight"],
    photo: ["photography", "creative", "content-creation"],
    video: ["videography", "creative", "content-creation"],
    play: ["gaming", "casual-gaming"],
    fitness: ["health-monitoring", "exercise"],
    music: ["audiophile", "commute"],
  };

  for (const [key, vals] of Object.entries(aliases)) {
    if (useCase.includes(key) && vals.includes(uc)) return true;
    if (uc.includes(key) && vals.some(v => useCase.includes(v))) return true;
  }
  return false;
}
